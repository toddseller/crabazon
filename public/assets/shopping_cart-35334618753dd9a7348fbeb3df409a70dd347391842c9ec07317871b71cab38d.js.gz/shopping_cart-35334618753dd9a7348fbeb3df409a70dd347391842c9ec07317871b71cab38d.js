// var add_product = function(event){
// 	event.preventDefault()
// 	event.stopPropagation();
// 	console.log('hello')
// 	var button_id = $(this).attr('id')
// 	var id = button_id.slice(4)

//     $.ajax({url: "/carts/" + id , 
//     	   type: 'POST',
//     	   dataType: 'json'
//     	   })
// };
